#include <stdio.h>
int main()
{
    float a;
    printf("Enter any  number : ");
    scanf("%f", &a);
    printf(" Integer part is : %d", (int)a);
    return 0;
}