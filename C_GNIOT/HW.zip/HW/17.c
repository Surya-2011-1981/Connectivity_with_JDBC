#include <stdio.h>
int main()
{
    float a, b;
    printf("Enter any  number : ");
    scanf("%f %f", &a, &b);
    printf(" Integer Sum is : %d", (int)a + (int)b);
    return 0;
}