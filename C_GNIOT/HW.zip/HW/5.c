#include <stdio.h>
int main()
{
    int a, b, c;
    printf("Enter any three number : ");
    scanf("%d %d %d", &a, &b, &c);
    printf("The sum is : %d ", (a + b + c));
    return 0;
}