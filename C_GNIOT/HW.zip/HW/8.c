#include <stdio.h>
int main()
{
    int l, b;
    printf("Enter length : ");
    scanf("%d", &l);
    printf("Enter breadth : ");
    scanf("%d", &b);
    printf("Area of recangle is : %d", (l * b));
    return 0;
}